# Revisión del 21 de octubre de 2026

Se conservó el avance local y su dirección visual oscura. Claude Code realizó una revisión independiente de los tres archivos originales en modo lectura; sus hallazgos se contrastaron antes de corregirlos.

## Correcciones

- Horas recalculadas sobre 13 800 millones de años = 86 400 segundos.
- Primeras estrellas: 00:21 (~13 600 millones de años atrás).
- Vía Láctea: 00:31 (~13 500 millones); referencia a sus estrellas antiguas, no a la aparición instantánea de su estructura actual.
- Sol: 16:00 (4 600 millones).
- Tierra: 16:06 (4 540 millones).
- Vida temprana: 17:55 (~3 500 millones); evidencia temprana y no una fecha definitiva de origen.
- Oxigenación: 19:50 (~2 400 millones).
- Explosión cámbrica: 23:04 (~540 millones), diferenciada del origen de toda vida compleja.
- Homo sapiens: 23:59:58 (~300 000 años, unos 1.88 segundos).
- Texto visible aunque falle JavaScript; foco de teclado; salto al contenido; progreso etiquetado; reloj sin anuncios repetitivos.
- Pausa de animación, respeto a movimiento reducido y suspensión del render en pestaña oculta.
- Densidad de píxeles limitada a 2; degradado reutilizado; scroll agrupado por cuadro.
- Explicación de escala y fuentes enlazadas. Barra = lectura; reloj = hito. No se representa el tiempo mediante altura proporcional.

## Fuentes

- https://spaceplace.nasa.gov/galaxies-age/en/
- https://ntrs.nasa.gov/api/citations/20250001759/downloads/Hasan_Canada_2025.pdf?attachment=true
- https://science.nasa.gov/sun/facts/
- https://hinode.msfc.nasa.gov/lc_timeline1.html
- https://ocean.si.edu/through-time/ocean-through-time
- https://naturalhistory.si.edu/education/teaching-resources/life-science/early-life-earth-animal-origins
- https://humanorigins.si.edu/evidence/human-fossils/species/homo-sapiens

## Verificación

JavaScript validado con node --check; servidor local con HTTP 200.
Revisión visual real de portada y cierre en navegador de escritorio.
Probados: pausa, navegación Cómo leer y apertura de explicación.
Las fechas se redondean al minuto salvo Homo sapiens. No son mediciones exactas.
Pendiente de prueba directa: dispositivos móviles físicos y lectores de pantalla.

## Recuperación de entradas animadas

La regla de visibilidad de finish.css había anulado accidentalmente las entradas CSS. Se restauraron mediante Web Animations API: opacidad y desplazamiento de 22 px, duración de 1.2 s, una vez por elemento al entrar en pantalla. El texto base continúa visible si JavaScript falla. Pausar cancela las entradas activas; movimiento reducido omite el desplazamiento.
Claude Code confirmó que el fondo original conserva parpadeo, anillos y cambios de tono por sección. La copia local original no contenía parallax de estrellas ligado al desplazamiento; no se añadió un efecto distinto como supuesto reemplazo.
